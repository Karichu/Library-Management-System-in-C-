﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Programming_2_Project
{
    public partial class IssueBooks : Form
    {
        public IssueBooks()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void IssueBooks_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "data source = DESKTOP-A9B8Q43 ; database=library; integrated security=True";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.Open();

            cmd = new SqlCommand("Select bName from Books", con);
            SqlDataReader Sdr = cmd.ExecuteReader();


            while(Sdr.Read())
            {
                for(int i=0;i<Sdr.FieldCount;i++)
                {
                    ComboBoxbooks.Items.Add(Sdr.GetString(i));
                }
            }
            Sdr.Close();
            con.Close();
        }
        int count;
        private void btnsearch_Click(object sender, EventArgs e)
        {
            if(txtstudentid.Text !="")
            {
                String stid = txtstudentid.Text;
                SqlConnection con = new SqlConnection();
                con.ConnectionString = "data source = DESKTOP-A9B8Q43 ; database=library; integrated security=True";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "Select * from NewStudent where studid= '" + stid + "'";
                SqlDataAdapter DA = new SqlDataAdapter(cmd);
                DataSet DS = new DataSet();
                DA.Fill(DS);
                //----------------------------------------------------------


                //-------------------------code to count how many books have been issued on this student id

                cmd.CommandText = "Select count(studid) from IRbook where studid= '" + stid + "' and book_returndate is null";
                SqlDataAdapter DA1 = new SqlDataAdapter(cmd);
                DataSet DS1 = new DataSet();
                DA.Fill(DS1);

                count = int.Parse(DS1.Tables[0].Rows[0][0].ToString());
                //----------------------------------------------------------






                if (DS.Tables[0].Rows.Count !=0)
                {
                    txtname.Text = DS.Tables[0].Rows[0][2].ToString();
                    txtphone.Text = DS.Tables[0].Rows[0][3].ToString();
                    txtemail.Text = DS.Tables[0].Rows[0][4].ToString();

                }
                else
                {
                    txtname.Clear();
                    txtphone.Clear();
                    txtemail.Clear();
                    MessageBox.Show("Invalid Enrollment No", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }


            }
        }

        private void btnIssue_Click(object sender, EventArgs e)
        {
            if (txtname.Text !="")
            {
                if(ComboBoxbooks.SelectedIndex!= -1 &&count<=2)
                {
                    String id= txtstudentid.Text;
                    String name = txtname.Text;
                    Int64 phone = Int64.Parse(txtphone.Text);
                    String email = txtemail.Text;
                    String bookname = ComboBoxbooks.Text;
                    String bookissue = dateTimePicker.Text;



                    String stid = txtstudentid.Text;
                    SqlConnection con = new SqlConnection();
                    con.ConnectionString = "data source = DESKTOP-A9B8Q43 ; database=library; integrated security=True";
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    con.Open();

                    cmd.CommandText = cmd.CommandText= "insert into IRbook (studid,stdname,stdphone,stdemail,book_name,book_issuedate) values ('"+id+"','"+name+ "','" + phone + "','" + email+"','"+bookname+"','"+bookissue+"')";
                    cmd.ExecuteNonQuery();
                    con.Close();


                    MessageBox.Show("Book issued","Success",MessageBoxButtons.OK,MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Select Book.OR Maximum number of Book has been issued", "No Book Selected", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Enter valid studentID", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtstudentid_TextChanged(object sender, EventArgs e)
        {
            if(txtstudentid.Text =="")
            {
                txtname.Clear();
                txtphone.Clear();
                txtemail.Clear();
            }
        }

        private void btnrefresh_Click(object sender, EventArgs e)
        {
            txtstudentid.Clear(); 
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Are you sure?", "Confirmation",MessageBoxButtons.OKCancel,MessageBoxIcon.Warning)== DialogResult.OK)
            {
                this.Close();
            }
           
        }
    }
}
