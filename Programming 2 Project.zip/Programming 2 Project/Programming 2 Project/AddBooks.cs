﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Programming_2_Project
{
    public partial class AddBooks : Form
    {
        public AddBooks()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            if (txtbookname.Text != "" && txtauthorname.Text != "" && txtpublication.Text != "" && txtprice.Text != "" && txtquantity.Text != "")
            {



                String bname = txtbookname.Text;
                String bauthor = txtauthorname.Text;
                String publication = txtpublication.Text;
                Int64 price = Int64.Parse(txtprice.Text);
                Int64 quantity = Int64.Parse(txtquantity.Text);

                SqlConnection con = new SqlConnection();
                con.ConnectionString = "data source = DESKTOP-A9B8Q43; database = library; integrated security=True";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;

                con.Open();
                cmd.CommandText = "insert into Books (bName,bAuthor,bPubl,bPrice,bQuan) values ('" + bname + "','" + bauthor + "','" + publication + "'," + price + "," + quantity + ")";
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Data Saved.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtbookname.Clear();
                txtauthorname.Clear();
                txtpublication.Clear();
                txtprice.Clear();
                txtquantity.Clear();
            }
            else
            {
                MessageBox.Show("Empty Field NOT allowed", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("This will DELETE your unsaved data.", "Are you sure?", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)

            {
                this.Close();
            }
        }
    }
}
