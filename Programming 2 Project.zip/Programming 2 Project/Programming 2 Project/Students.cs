﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Programming_2_Project
{
    public partial class Students : Form
    {
        public Students()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (txtstudent.Text != "" && txtname.Text != "" && txtphone.Text != "" && txtemail.Text != "") 
            {

                String id = txtstudent.Text;
                String name = txtname.Text;
                Int64 phone = Int64.Parse(txtphone.Text);
                String email = txtemail.Text;


                SqlConnection con = new SqlConnection();
                con.ConnectionString = "data source = DESKTOP-A9B8Q43 ; database=library; integrated security=True";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;

                con.Open();
                cmd.CommandText = "insert into NewStudent (studid,sname,phone,email) values('" + id + "','" + name + "'," + phone + ",'" + email + "')";
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Data Saved!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Please fill empty Fields", "Suggest", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

            private void btnexit_Click(object sender, EventArgs e)
            {
                if (MessageBox.Show("Confirm?", "Alert", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
                {
                    this.Close();
                }
            }

            private void btnrefresh_Click(object sender, EventArgs e)
            {
                txtstudent.Clear();
                txtname.Clear();
                txtphone.Clear();
                txtemail.Clear();

                // txtemail.Text = "";
            }

        private void txtname_TextChanged(object sender, EventArgs e)
        {

        }

        private void Students_Load(object sender, EventArgs e)
        {

        }
    }
    }
